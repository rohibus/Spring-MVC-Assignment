package com.bookstore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "loved_books")
@SequenceGenerator(name = "loved_books_seq", allocationSize = 1, initialValue = 1)
public class LovedBook {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "loved_books_seq")
	private Long id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "book_id")
	private Long bookId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

}
