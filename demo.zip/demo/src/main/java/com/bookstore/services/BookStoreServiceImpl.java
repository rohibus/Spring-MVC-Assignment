package com.bookstore.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;
import com.bookstore.repository.BookStoreRepo;
import com.bookstore.repository.LovedBookRepo;
import com.bookstore.repository.ReadLaterRepo;

@Service
public class BookStoreServiceImpl implements BookStoreService {

	@Autowired
	BookStoreRepo bookStoreRepo;

	@Autowired
	LovedBookRepo lovedBookRepo;

	@Autowired
	ReadLaterRepo readLaterRepo;

	public List<Book> getAllBooks() {
		return bookStoreRepo.findAll();
	}

	public void addToLovedBook(LovedBook book) {
		lovedBookRepo.save(book);
	}

	public void addReadLater(ReadLater ReadLater) {
		readLaterRepo.save(ReadLater);
	}

	public List<Book> getReadLaterByUserId(Long userId) {
		List<ReadLater> books = readLaterRepo.getReadLaterByUserId(userId);
		List<Long> ids = books.stream().map(ReadLater::getId).collect(Collectors.toList());
		return bookStoreRepo.getBooks(ids);
	}

	public List<Book> getLovedBooksByUserId(Long userId) {
		List<LovedBook> books = lovedBookRepo.getLovedBooksByUserId(userId);
		List<Long> ids = books.stream().map(LovedBook::getId).collect(Collectors.toList());
		return bookStoreRepo.getBooks(ids);
	}

}
