package com.bookstore.services;

import java.util.List;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;

public interface BookStoreService {

	public List<Book> getAllBooks();

	public void addToLovedBook(LovedBook book);

	public void addReadLater(ReadLater ReadLater);

	public List<Book> getReadLaterByUserId(Long userId);

	public List<Book> getLovedBooksByUserId(Long userId);

}
