package com.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;
import com.bookstore.services.BookStoreService;

@RestController
@RequestMapping(value = "/bookstore")
public class BookStoreController {

	@Autowired
	BookStoreService bookStoreService;

	@RequestMapping(value = "/getAllBooks", method = RequestMethod.GET)
	public List<Book> getAllBooks() {
		return bookStoreService.getAllBooks();
	}

//	@RequestMapping(value = "/login", method = RequestMethod.POST)
//	public List<Book> getAllBooks(@RequestBody User user) {
//		//return bookStoreService.getAllBooks();
//	}

	@RequestMapping(value = "/addLovedBook", method = RequestMethod.POST)
	public void addLovedBook(@RequestBody LovedBook lovedBook) {
		bookStoreService.addToLovedBook(lovedBook);
	}

	@RequestMapping(value = "/addToReadLater", method = RequestMethod.POST)
	public void addLovedBook(@RequestBody ReadLater readLater) {
		bookStoreService.addReadLater(readLater);
	}

	@RequestMapping(value = "/getLovedBooksByUserId/{userId}", method = RequestMethod.GET)
	public List<Book> getLovedBooksByUserId(@PathVariable Long userId) {
		return bookStoreService.getLovedBooksByUserId(userId);
	}

	@RequestMapping(value = "/getReadLaterByUserId/{userId}", method = RequestMethod.GET)
	public List<Book> getReadLaterByUserId(@PathVariable Long userId) {
		return bookStoreService.getReadLaterByUserId(userId);
	}

}
