package com.bookstore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bookstore.model.LovedBook;

@Repository
public interface LovedBookRepo extends JpaRepository<LovedBook, Long> {
	
	@Query( value = "from LovedBook dcs where dcs.userId = :id" )
	List<LovedBook> getLovedBooksByUserId( @Param( "id" ) Long id );
}
