package com.bookstore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bookstore.model.ReadLater;

@Repository
public interface ReadLaterRepo extends JpaRepository<ReadLater, Long> {
	@Query(value = "from ReadLater dcs where dcs.userId = :id")
	List<ReadLater> getReadLaterByUserId(@Param("id") Long id);
}